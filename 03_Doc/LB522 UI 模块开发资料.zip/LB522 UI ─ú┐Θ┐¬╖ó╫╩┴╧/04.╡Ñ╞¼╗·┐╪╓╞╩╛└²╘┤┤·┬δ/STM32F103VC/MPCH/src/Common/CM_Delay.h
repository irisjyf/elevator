#ifndef CM_DELAY_H
#define CM_DELAY_H
/**	header files	*/

/**	defines		*/

/**	structures	*/

/**	variables		*/

/**	functions		*/
extern void mdelay(U32 msnum);
extern void delay_1sec(void);
extern void Delay_150ms(void);

#endif
