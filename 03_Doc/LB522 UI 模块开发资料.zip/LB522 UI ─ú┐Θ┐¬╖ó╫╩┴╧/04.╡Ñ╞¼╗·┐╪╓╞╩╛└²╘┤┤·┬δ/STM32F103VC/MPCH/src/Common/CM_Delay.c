/**	header files	*/
#include "MPCH.h"

/**	defines		*/

/**	structures	*/

/**	variables		*/

/**	functions		*/

//start	/////////////////////  internal functions ////////////////////
U8 JudgeTimeIsOver(U32 intime,U32 overtime)
{
	if(SysTickNum>=intime)
	{
	 	if((SysTickNum-intime)>=overtime)return TRUE;
	}
	else
	{
	 	if((0x100000000-intime+SysTickNum)>=overtime)return TRUE;
	}
	return FALSE; 
}

//end	\\\\\\\\\\\\\\\\\\\\\\\\\\\\\  internal functions \\\\\\\\\\\\\\\\\\\\\\\\\\\\

void mdelay(U32 msnum)
{
 	U32	nowtime=SysTickNum;

	while(1)
	{
		if(JudgeTimeIsOver(nowtime,msnum)==TRUE)return;
	}
}

void delay_1sec(void)
{
	mdelay(1000);
}

void Delay_150ms(void)
{
	mdelay(150);
}

