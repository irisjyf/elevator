/**	header files	*/
#include "Routine.h"

/**	defines		*/

/**	structures	*/

/**	variables		*/

/**	functions		*/
void Rt_init(void)
{
	Rt_PhysicsDevice_init();		//�����豸��ʼ��
	Rt_LogicDevice();				//�߼��豸��ʼ��
}

void Rt_PhysicsDevice_init(void)
{
	Pd_Usart3_Init(115200);
}

void Rt_LogicDevice(void)
{
	;
}
