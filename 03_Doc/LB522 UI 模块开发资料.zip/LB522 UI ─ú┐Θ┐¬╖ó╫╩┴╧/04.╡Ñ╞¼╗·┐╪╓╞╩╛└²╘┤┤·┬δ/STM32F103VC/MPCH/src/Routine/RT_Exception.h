#ifndef RT_EXCEPTION_H
#define RT_EXCEPTION_H

extern unsigned int SysTickNum;

#endif 
