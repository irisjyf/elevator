#ifndef RT_INIT_H
#define RT_INIT_H

extern void Rt_init(void);
extern void Rt_PhysicsDevice_init(void);
extern void Rt_LogicDevice(void);

#endif
