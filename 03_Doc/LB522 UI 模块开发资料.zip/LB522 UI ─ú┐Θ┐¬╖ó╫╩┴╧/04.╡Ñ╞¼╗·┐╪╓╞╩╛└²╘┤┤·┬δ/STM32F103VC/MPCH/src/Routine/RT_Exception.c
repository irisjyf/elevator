/**	header files	*/
#include "MPCH.h"

U32 SysTickNum = 0;

void HardFault_Handler(void)
{
	NVIC_SETFAULTMASK();
	NVIC_GenerateSystemReset();	
	while(1)
	{
		;
	}
}

void SysTick_Handler(void)
{
	SysTickNum++;
}

void USART3_IRQHandler(void)
{
	Pd_Usart3_Irq();
}

