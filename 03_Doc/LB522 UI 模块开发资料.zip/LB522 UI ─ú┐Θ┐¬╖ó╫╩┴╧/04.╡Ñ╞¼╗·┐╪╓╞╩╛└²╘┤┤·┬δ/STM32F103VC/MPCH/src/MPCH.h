#ifndef MPCH_H
#define MPCH_H

/**	header files	*/
#include "stm32f10x_lib.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "DataType.h" 
#include "version.h"
#include "Hardware.h"
#include "Common.h"
#include "Routine.h"
#include "RFID.h"

#endif
