#ifndef VERSION_H
#define VERSION_H

#define PROGRAM_VERSION  "MPCH_V1.0.0KKc"


#endif
