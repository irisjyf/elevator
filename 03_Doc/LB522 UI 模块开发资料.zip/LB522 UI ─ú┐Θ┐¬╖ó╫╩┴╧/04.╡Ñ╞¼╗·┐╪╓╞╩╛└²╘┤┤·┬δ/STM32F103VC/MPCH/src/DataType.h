
#ifndef APP_DATATYPE_H
#define APP_DATATYPE_H

//Basic data type
#define	U8			unsigned char		//unsigned 8 bit data  
#define	U16			unsigned short		//unsigned 16 bit data
#define	U32			unsigned int 		//unsigned 32 bit data
#define	S8			char 				//signed 8 bit data
#define	S16			short 				//signed 16 bit data
#define	S32			int 				//signed 32 bit data
#define	F32			float 				//32 bit float data

#define	P_U8		U8 * 
#define	P_U16		U16 * 
#define	P_U32		U32 * 
#define	P_S8		S8 * 
#define	P_S16		S16 * 
#define	P_S32		S32 * 
#define	P_F32		F32 * 

#define	HEX			U8
#define	BCD			U8 
#define	ASC			U8

#define	P_BCD		BCD* 
#define	P_ASC		ASC*

//logic value
#define TRUE    	1
#define FALSE   	0
#define ERROR		-1
#define NULL 0
#define NOINPUT		2

//ASC
#define	ASC_0		'0'
#define	ASC_1		'1'

#define UNUSED(p) p=p



//#include "HW_DataType.h"
//#include "CM_DataType.h"
//#include "RT_DataType.h"


#endif

