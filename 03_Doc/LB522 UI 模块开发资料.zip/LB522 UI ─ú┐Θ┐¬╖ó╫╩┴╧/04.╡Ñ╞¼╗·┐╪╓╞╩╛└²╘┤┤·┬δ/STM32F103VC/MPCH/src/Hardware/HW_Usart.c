/**	header files	*/
#include "MPCH.h"

/**	defines		*/

/**	variables	*/

/**	functions	*/

//-------------------------USART 3 ----------------------------------
/*******************************************************************************
* Function Name  : Pd_Usart3_Init
* Description    : ���ô���3���̶�����(N,8,1)���������ƣ������ʿ�����
*				   �������ó��ж�ģʽ���ж����ȼ�(1:1)
* Input          : U32 BaudRate �����ʣ�(1200~115200)
* Output         : None
* Return         : None
*******************************************************************************/
void Pd_Usart3_Init(U32 BaudRate)
{	 
	USART_InitTypeDef USART_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Enable GPIOD and USART3 clocks */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

	GPIO_PinRemapConfig(GPIO_FullRemap_USART3, ENABLE);

	/* Configure USART3 Tx (PD.8) as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	/* Configure USART3 Rx (PD.9) as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = BaudRate;

	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_InitStructure.USART_Clock = USART_Clock_Disable;
	USART_InitStructure.USART_CPOL = USART_CPOL_Low;
	USART_InitStructure.USART_CPHA = USART_CPHA_2Edge;
	USART_InitStructure.USART_LastBit = USART_LastBit_Disable;
	
	/* Configure the USART3 */
	USART_Init(USART3, &USART_InitStructure);
	
	USART_ClearITPendingBit(USART3, USART_IT_RXNE);
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
	USART_ITConfig(USART3, USART_IT_TXE,  DISABLE);

	/* Enable the USART3 Interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	/* Enable USART3 */
	USART_Cmd(USART3, ENABLE);
}

/*******************************************************************************
* Function Name  : Pd_Usart3_DeInit
* Description    : ȡ�����ô���3
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Pd_Usart3_DeInit(U32 BaudRate)
{
	USART_DeInit(USART3);
}
/*******************************************************************************
* Function Name  : Pd_Usart3_DeInit
* Description    : ����3�����ֽ�����
* Input          : 	U8 Data		:Ҫ���͵�����
*					U8 Delay	:�������ݺ����ʱ��ֻ�ڸ��ٺ�pcͨѶ��ʱ�򣬽����5000����ʱ�������龰��Ϊ0
* Output         : None
* Return         : None
*******************************************************************************/
void Pd_Usart3_SendData(U8 Data,U8 Delay)
{	 
	USART_SendData(USART3,Data);
	while(USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
	while(Delay--);
}
/*******************************************************************************
* Function Name  : Pd_Usart3_DeInit
* Description    : ����3���Ͷ�������
* Input          : 	U8 *Databuf	:�������ݻ���
*					U16 Len		:�������ݳ���
* Output         : None
* Return         : None
*******************************************************************************/
void Pd_Usart3_SendBuf(U8 *Databuf,U16 Len)
{
	U16 i;
	for(i=0;i<Len;i++){
		Pd_Usart3_SendData(Databuf[i],PD_USRAT_DELAY);
	}
}
/*******************************************************************************
* Function Name  : Pd_Usart3_Irq
* Description    : ����3�жϽ��գ����յ�������Ϊuartdata
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/   
void Pd_Usart3_Irq(void)		
{
	U8 uartdata = 0;
	
	if(USART_GetITStatus(USART3, USART_IT_IDLE) != RESET)
	{   
		/* Clear the USART3 transmit interrupt */
		USART_ClearITPendingBit(USART3, USART_IT_IDLE); 
	}  
	if(USART_GetITStatus(USART3, USART_IT_ORE) != RESET)
	{   
		/* Clear the USART3 transmit interrupt */
		USART_ClearITPendingBit(USART3, USART_IT_ORE); 
	}  

	if(USART_GetITStatus(USART3, USART_IT_TC) != RESET)
	{   
		/* Clear the USART3 transmit interrupt */
		USART_ClearITPendingBit(USART3, USART_IT_TC); 
	}  
	if(USART_GetITStatus(USART3, USART_IT_TXE) != RESET)
	{   
		/* Write one byte to the transmit data register */
		//    USART_SendData(USART3, TxBuffer[TxCounter++]);                    
		/* Clear the USART3 transmit interrupt */
		USART_ClearITPendingBit(USART3, USART_IT_TXE); 
	}  
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
	{
		/* Clear the USART3 Receive interrupt */
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);
	    uartdata =(U8)(USART_ReceiveData(USART3));
		subp_RFID_Rx(uartdata);
	}
}

