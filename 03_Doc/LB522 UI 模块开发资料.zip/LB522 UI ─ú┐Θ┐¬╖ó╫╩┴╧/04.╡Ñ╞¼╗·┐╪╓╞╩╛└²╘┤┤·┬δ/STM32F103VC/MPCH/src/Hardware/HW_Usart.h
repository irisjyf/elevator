#ifndef PD_USART_H
#define PD_USART_H
/**	defines		*/
#define PD_USRAT_DELAY	(U8)(0)
/**	variables		*/

/**	functions		*/
//-------------------------USART 1 ----------------------------------
extern void Pd_Usart1_Init(U32 BaudRate);
extern void Pd_Usart1_DeInit(U32 BaudRate);
extern void Pd_Usart1_SendData(U8 Data,U8 Delay);
extern void Pd_Usart1_SendBuf(U8 *Databuf,U16 Len);  
extern void Pd_Usart1_Irq(void);		
//-------------------------USART 2 ----------------------------------
extern void Pd_Usart2_Init(U32 BaudRate);
extern void Pd_Usart2_DeInit(U32 BaudRate);
extern void Pd_Usart2_SendData(U8 Data,U8 Delay);
extern void Pd_Usart2_SendBuf(U8 *Databuf,U16 Len);  
extern void Pd_Usart2_Irq(void);		
//-------------------------USART 3 ----------------------------------
extern void Pd_Usart3_Init(U32 BaudRate);
extern void Pd_Usart3_DeInit(U32 BaudRate);
extern void Pd_Usart3_SendData(U8 Data,U8 Delay);
extern void Pd_Usart3_SendBuf(U8 *Databuf,U16 Len);
extern void Pd_Usart3_Irq(void);
#endif

