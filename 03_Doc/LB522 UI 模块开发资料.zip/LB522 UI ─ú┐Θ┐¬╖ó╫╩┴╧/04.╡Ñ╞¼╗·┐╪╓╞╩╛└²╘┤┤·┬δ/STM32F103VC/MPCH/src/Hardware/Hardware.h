#ifndef HARDWARE_H
#define HARDWARE_H

#include "HW_Mcu.h"
#include "HW_Usart.h"

#endif 