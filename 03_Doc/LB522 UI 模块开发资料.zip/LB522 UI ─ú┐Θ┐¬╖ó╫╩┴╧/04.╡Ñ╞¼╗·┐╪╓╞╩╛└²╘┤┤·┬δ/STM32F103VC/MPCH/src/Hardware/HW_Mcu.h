#ifndef HW_MCU_H
#define HW_MCU_H

extern void Mcu_BaseInit(void);

#endif
